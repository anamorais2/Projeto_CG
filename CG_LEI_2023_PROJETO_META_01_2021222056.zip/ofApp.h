#pragma once

#include "ofMain.h"
#include "cg_extras.h"
#include "cg_drawing_extras.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		
		//floor
		GLint resX, resY;
		GLfloat floorWidth, floorHeight, floorHeightPos;

		//base prédio
		GLfloat baseWidth, baseDepth, baseHeight;
		GLint basePosX, basePosY;
		ofVec3f basePos;


		//view
		int view;

		//Controlo perspetiva
		int perspectiveView;

		//Rotação segundo as setas
		GLfloat rotationAngleY;
		GLfloat rotationAngleX;
		GLfloat rotationSpeed;
		int prevMouseX, prevMouseY;

		//Angulo de rotaçao para o telhado
		GLfloat rotationAngle;

		//Coordenadas para o primeiro prédio
		GLfloat buildingPosX;
		GLfloat buildingPosY;
		GLfloat buildingPosZ;
		GLfloat buildingWidth;
		GLfloat buildingHeight;
		GLfloat buildingDepth;

		//Variáveis controlo elevador
		GLfloat elevatorSpeed;
		GLfloat elevatorPosX;
		GLfloat elevatorPosY;
		GLfloat elevatorPosZ;
		GLfloat elevatorWidth;
		GLfloat elevatorHeight;
		GLfloat elevatorDepth;

		

		
};