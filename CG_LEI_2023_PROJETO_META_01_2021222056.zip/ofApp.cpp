
#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
	glEnable(GL_DEPTH_TEST);
	coutModelviewMatrix();
	ofBackground(0.11, 0.11, 0.11);
	glLineWidth(5);

	//view
	view = 0;

	//perspectiva View
	perspectiveView = 0;
	
	//floor parameters
	resX = 5;
	resY = 5;
	floorWidth = gw() * 0.5;
	floorHeight = gw() * 0.5;
	floorHeightPos = 0.;//gh() * 0.75;
	
	//floorBasePredio
	baseWidth = floorWidth / GLfloat(resX);
	baseHeight = floorHeight / GLfloat(resY);
	baseDepth = baseWidth;

	basePosX = floor(resX / 2);
	basePosY = floor(resY / 2);
	basePos.z = floorHeightPos + baseDepth * 0.5;

	//Rotação segundo as setas do teclado
	rotationAngleX = 0.0;
	rotationAngleY = 0.0;
	rotationSpeed = 1.0;

	//angulo Rotacao Telhado
	rotationAngle = 0.0;

	//velocidade elevador
	elevatorSpeed = 1;

	//Posição do elevador
	elevatorPosX = 0.0;
	elevatorPosY = 0.0;
	elevatorPosZ = 0.0;
	elevatorWidth = baseWidth / 4;
	elevatorHeight = baseHeight / 4;
	elevatorDepth = baseDepth / 3;



}

//--------------------------------------------------------------
void ofApp::update(){

	//Rotação do angulo do telhado rotativo
	rotationAngle += 1.0;


	// Atualiza a posição do elevador
	elevatorPosZ += elevatorSpeed;

	// Verifica se o elevador atingiu os limites superior ou inferior
	if (elevatorPosZ > (baseDepth * 5 - elevatorDepth) || elevatorPosZ <= -(elevatorDepth*0.05)+2) {
		elevatorSpeed *= -1;  // Inverte a direção do movimento
	}
		
}

//--------------------------------------------------------------
void ofApp::draw() {
	glColor3f(0.588, 0.58, 0.573);
	
	if (perspectiveView == 1) {

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		const GLfloat theta = 100.0;  //Campo de visão
		const GLfloat alpha = 4.0 / 3.0;  //Razão de aspeto (largura/altura da tela)
		const GLfloat beta = 150.0f; //Plano de clipping (Define o que está dentro da "caixa" de visão)

		perspective(theta, alpha, beta, false, true);
	}
	else if ((perspectiveView == 2)) {

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		glOrtho(-gw() / 2, gw() / 2, gh() / 2, -gh() / 2, -10000, 10000);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	switch (view) {
	case 0:
		//vista de cima
		glTranslatef(gw() * 0.5, gh() * 0.5, 0);
		lookat(0,0,800,0,0,1,
			0, 1, 0);
		break;
	case 1:
		//vista de frente, da altura do chão
		lookat(0, gh(), 10,
			0, 0, 10,
			0, 0, -1);
		glTranslatef(0, 10, -100);
		break;
	case 2:
		//vista de lado esquerdo
		lookat(-gw(), 0, 0,
			0, 0, gw()/3,
			0, 0, -1);
		break;
	case 3:
		//vista de lado direito
		lookat(gw(), 0, 0,
			0, 0, gw() / 3,
			0, 0, -1);
		break;
	case 4:
		//vista de trás
		lookat(0, -gh(), 10,
			0, 0, 10,
			0, 0, -1);
		glTranslatef(0, 100, -100);
		break;
	}

	glPushMatrix();//master push

	// Aplicar rotações com as setas
	glRotatef(rotationAngleX, 1, 0, 0);
	glRotatef(rotationAngleY, 0, 1, 0);

	// floor
	glPushMatrix(); // floor push
	glScalef(floorWidth, floorHeight, 1.);
	malha_unit(resX, resY);
	glPopMatrix(); // floor pop


	glLineWidth(2);

	// Desenhar o primeiro prédio
	buildingPosX = basePos.x; // Coordenadas X do prédio
	buildingPosY = basePos.y + 1; // Coordenadas Y do prédio (acima do floor)
	buildingPosZ = basePos.z; // Coordenadas Z do prédio 
	buildingWidth = baseWidth; // Largura do prédio
	buildingHeight = baseHeight; // Altura do prédio 
	buildingDepth = baseDepth * 2; // Profundidade do prédio

	glPushMatrix(); 
	glTranslatef(0, 0, baseDepth / 2 + 1); // Mover 1 unidade acima no eixo Z
	drawBuildingMalha(buildingPosX, buildingPosY, buildingPosZ, buildingWidth, buildingHeight, buildingDepth, 1, 0, 1,6,5);
	glPopMatrix(); 

	// Desenhar o segundo prédio
	glPushMatrix(); 
	glTranslatef(0, 0, 21);
	drawBuilding(basePos.x + baseWidth + 1, basePos.y + 1, basePos.z, baseWidth, baseHeight, baseDepth + 40, 1, 0, 0.2);
	glPopMatrix(); 

	// Desenhar o terceiro prédio
	glPushMatrix(); 
	glTranslatef(0, 0, baseDepth * 0.01);
	drawBuilding(basePos.x + 2 * baseWidth + 2, basePos.y + 1, basePos.z, baseWidth, baseHeight, baseDepth, 1, 1, 0.2);
	glPopMatrix(); 

	// Desenhar o quarto prédio
	glPushMatrix();
	glTranslatef(0, 0, 21);
	drawBuilding(-(basePos.x + baseWidth + 1), basePos.y + 1, basePos.z, baseWidth, baseHeight, baseDepth + 40, 0.2, 0.2, 0);
	glPopMatrix();

	// Desenhar o quinto prédio
	glPushMatrix(); 
	glTranslatef(0, 0, baseDepth * 0.01);
	drawBuilding(-(basePos.x + 2 * baseWidth + 2), basePos.y + 1, basePos.z, baseWidth, baseHeight, baseDepth, 0.2, 1, 0.2);
	glPopMatrix(); 

	// Desenhar o telhado (pirâmide quadrangular) em cima do primeiro prédio
	float roofSize = buildingWidth / 2; //Tamanho do telhado conforme a largura do primeiro prédio
	float roofPosX = buildingPosX; // Posição X do telhado (alinhado com o prédio)
	float roofPosY = buildingPosY ; // Posição Y do telhado (acima do prédio)
	float roofPosZ = buildingPosZ + buildingHeight + roofSize + 1; // Posição Z do telhado (mesmo nível do prédio)

	glPushMatrix(); 
	glTranslatef(roofPosX, roofPosY, roofPosZ);

	// Ajustar a rotação para que o pico da pirâmide esteja orientado corretamente
	glRotatef(-90,1,0,0); 
	glRotatef(180, 0, 0, 1); 
	//Rotação constante do telhado
	glRotatef(rotationAngle, 0, 1, 0);
	glColor3f(0, 1, 0.804);
	drawPyramidRoof(0, 0, 0, roofSize); 
	glPopMatrix(); 

	// Desenhar sexto prédio
	glPushMatrix(); 
	glTranslatef(0, 0, 1);
	drawBuilding(basePos.x + baseWidth + 1, basePos.y + baseWidth, basePos.z , baseWidth / 2, baseHeight / 2, baseDepth, 1, 0.62, 0);
	glPopMatrix(); 

	// Desenhar setimo prédio
	glPushMatrix();
	glTranslatef(0, 0, 1);
	drawBuilding(-(basePos.x + baseWidth + 1), basePos.y + baseWidth, basePos.z, baseWidth / 2, baseHeight / 2, baseDepth, 0, 0.686, 1);
	glPopMatrix(); 

	// Desenhar o oitavo prédio
	glPushMatrix();
	glTranslatef(0, 0, baseDepth * 0.01);
	drawBuildingMalha(basePos.x + 2 * baseWidth + 2, basePos.y + 2 * baseWidth, basePos.z / 2 + 1, baseWidth / 3, baseHeight/3, baseDepth/2, 0.988, 0.325, 0.835,5,5);
	glPopMatrix(); 

	// Desenhar o nono prédio
	glPushMatrix();
	glTranslatef(0, 0, baseDepth / 2 + 1); 
	drawBuildingMalha(basePos.x - (baseWidth + baseWidth/2) , basePos.y + 1 - 2* baseWidth, basePos.z, baseWidth * 2, baseHeight, baseDepth * 2, 0.525, 0, 1,7,7);
	glPopMatrix(); 
	
	// Desenhar o decimo prédio
	glPushMatrix(); 
	glTranslatef(0, 0, 21);
	drawBuilding(basePos.x, basePos.y + 1 - baseWidth, basePos.z, baseWidth, baseHeight, baseDepth + 40, 1, 0, 0.2);
	glPopMatrix();

	// Desenhar o decimo primeiro prédio
	glPushMatrix(); 
	glTranslatef(0, 0, baseDepth * 0.01);
	drawBuilding(basePos.x, basePos.y + 1 - 2 * baseWidth, basePos.z, baseWidth, baseHeight, baseDepth, 1, 1, 0.2);
	glPopMatrix(); 

	// Desenhar o decimo segundo prédio
	glPushMatrix();
	glTranslatef(0, 0, baseDepth * 0.01);
	drawBuildingMalha(-(basePos.x + 2 * baseWidth + 2), basePos.y + 2 * baseWidth, basePos.z / 2 + 1, baseWidth / 3, baseHeight / 3, baseDepth / 2, 1, 0, 0.694,4,4);
	glPopMatrix();

	// Desenhar o decimo terceiro prédio
	glPushMatrix();
	glTranslatef(0, 0, baseDepth /2 + 1);
	drawBuildingMalha(basePos.x + (baseWidth + baseWidth / 2), basePos.y + 1 - 2 * baseWidth, basePos.z, baseWidth * 2, baseHeight, baseDepth * 2, 0.325, 0.831, 0.988,7,7);
	glPopMatrix();

	// Desenhar decimo quarto prédio
	glPushMatrix();
	glTranslatef(0, 0, baseDepth*2 + 1);
	drawBuildingMalha(-(basePos.x + baseWidth + 1),  -(basePos.y + baseWidth), basePos.z, baseWidth/2 , baseHeight , baseDepth * 5, 0.988, 0.325, 0.533,5,5);
	glPopMatrix();

	// Desenhar torre decimo terceiro prédio
	glPushMatrix();
	glTranslatef(0, 0, baseDepth*2 + 2);
	drawBuildingMalha(basePos.x + (baseWidth + baseWidth / 2), basePos.y + 1 - 2 * baseWidth, basePos.z, baseWidth , baseHeight*1/2, baseDepth , 0.212, 0.557, 0.98, 7, 7);
	glPopMatrix();

	// Desenhar 2  torre decimo terceiro prédio
	glPushMatrix();
	glTranslatef(0, 0, baseDepth * 3 + 5);
	drawBuildingMalha(basePos.x + (baseWidth + baseWidth / 2), basePos.y + 1 - 2 * baseWidth, basePos.z, baseWidth/2, baseHeight * 1 / 5, baseDepth, 0.659, 0.435, 0.988, 7, 7);
	glPopMatrix();

	// Elevador no prédio mais alto
	glPushMatrix();
	glTranslated(-(basePos.x + baseWidth +1), -(basePos.y + baseWidth), basePos.z - elevatorDepth);
	drawElevator(elevatorPosX,elevatorPosY, elevatorPosZ, elevatorWidth, elevatorHeight, elevatorDepth);
	glPopMatrix();

	glPopMatrix(); // master pop
}


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	switch (key) {
	case '1':
		glDisable(GL_CULL_FACE);
		break;
	case '2':
		glEnable(GL_CULL_FACE);
		glCullFace(GL_BACK);
		break;
	case '3':
		glEnable(GL_CULL_FACE);
		glCullFace(GL_FRONT);
		break;
	case '4':
		glEnable(GL_CULL_FACE);
		glCullFace(GL_FRONT_AND_BACK);
		break;
	case 'g':
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		break;
	case 'f':
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		break;
	case 'p':
		perspectiveView++;
		if (perspectiveView > 2) {
			perspectiveView = 0;
		}
		break;
	case 'v':
		view++;
		if (view > 4) {
			view = 0;
		}
		break;

	case OF_KEY_UP:
		rotationAngleX += rotationSpeed;
		break;
	case OF_KEY_DOWN:
		rotationAngleX -= rotationSpeed;
		break;
	case OF_KEY_LEFT:
		rotationAngleY += rotationSpeed;
		break;
	case OF_KEY_RIGHT:
		rotationAngleY -= rotationSpeed;
		break;
	}
	
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
	int deltaX = x - prevMouseX;
	int deltaY = y - prevMouseY;

	rotationAngleX += deltaY * rotationSpeed;
	rotationAngleY += deltaX * rotationSpeed;

	prevMouseX = x;
	prevMouseY = y;
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
	prevMouseX = -x;
	prevMouseY = -y;
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
	setup();
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

