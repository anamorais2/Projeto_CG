#pragma once

#include "ofMain.h"
#include "cg_extras.h"
#include "ofApp.h"



//desenha axis 3D
inline void axis3d() {
	glBegin(GL_LINES);
	glColor3f(1, 0, 0);
	glVertex3f(0, 0, 0);
	glVertex3f(1, 0, 0);
	glColor3f(0, 1, 0);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 1, 0);
	glColor3f(0, 0, 1);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 0, 1);
	glEnd();
}

//função que desenha quadrado unitário 
//centrado na origem e preenchido
inline void rectFill_unit() {
	glBegin(GL_QUADS);
	glVertex3d(-0.5, -0.5, 0.);
	glVertex3d(-0.5, 0.5, 0.);
	glVertex3d(0.5, 0.5, 0.);
	glVertex3d(0.5, -0.5, 0.);
	glEnd();
}

//função que desenha malha unitária com resolução mxn
inline void malha_unit(GLint m, GLint n) {
	GLfloat x_start = -0.5;
	GLfloat y_start = -0.5;
	GLfloat x_step = 1.0 / GLfloat(m);
	GLfloat y_step = 1.0 / GLfloat(n);

	glBegin(GL_QUADS);
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			glVertex2d(i * x_step + x_start, j * y_step + y_start);
			glVertex2d(i * x_step + x_start, (j + 1) * y_step + y_start);
			glVertex2d((i + 1) * x_step + x_start, (j + 1) * y_step + y_start);
			glVertex2d((i + 1) * x_step + x_start, j * y_step + y_start);
		}
	}
	glEnd();
}


inline void cube_unit() {
	GLfloat p = 0.5;
	glBegin(GL_QUADS);

	//frente
	glVertex3f(-p, -p, p);
	glVertex3f(-p, p, p);
	glVertex3f(p, p, p);
	glVertex3f(p, -p, p);

	//tras
	glVertex3f(-p, -p, -p);
	glVertex3f(p, -p, -p);
	glVertex3f(p, p, -p);
	glVertex3f(-p, p, -p);

	//cima
	glVertex3f(-p, -p, -p);
	glVertex3f(-p, -p, p);
	glVertex3f(p, -p, p);
	glVertex3f(p, -p, -p);

	//baixo
	glVertex3f(-p, p, p);
	glVertex3f(-p, p, -p);
	glVertex3f(p, p, -p);
	glVertex3f(p, p, p);

	//esq
	glVertex3f(-p, -p, p);
	glVertex3f(-p, -p, -p);
	glVertex3f(-p, p, -p);
	glVertex3f(-p, p, p);

	//dir
	glVertex3f(p, -p, p);
	glVertex3f(p, p, p);
	glVertex3f(p, p, -p);
	glVertex3f(p, -p, -p);

	glEnd();

}

//Função para desenhar um prédio com o auxilio da função cube_unit()
inline void drawBuilding(float posX, float posY, float posZ, float width, float height, float depth, float colorR, float colorG, float colorB) {

	glPushMatrix();
	glTranslatef(posX, posY, posZ);

	glColor3f(colorR, colorG, colorB);
	glPushMatrix();
	glScalef(width, height, depth);
	cube_unit();
	glPopMatrix();
	glPopMatrix();
}

// Função para desenhar uma pirâmide quadrangular
inline void drawPyramidRoof(float posX, float posY, float posZ, float size) {
	glPushMatrix();

	// Mover para a posição especificada
	glTranslatef(posX, posY, posZ);

	glBegin(GL_TRIANGLES);

	// Definir a base da pirâmide
	glVertex3f(-size, 0, -size);
	glVertex3f(size, 0, -size);
	glVertex3f(size, 0, size);

	glVertex3f(-size, 0, -size);
	glVertex3f(size, 0, size);
	glVertex3f(-size, 0, size);

	glVertex3f(-size, 0, -size);
	glVertex3f(0, 2 * size, 0);
	glVertex3f(-size, 0, size);

	glVertex3f(size, 0, -size);
	glVertex3f(size, 0, size);
	glVertex3f(0, 2 * size, 0);

	glVertex3f(size, 0, -size);
	glVertex3f(-size, 0, -size);
	glVertex3f(0, 2 * size, 0);

	glVertex3f(-size, 0, size);
	glVertex3f(size, 0, size);
	glVertex3f(0, 2 * size, 0);
	glEnd();

	glPopMatrix();
}



// Draws a unit cube made of unit malhas centered in the origin 
	inline void cube_malha_unit(GLint m, GLint n) {
	GLfloat p = 0.5;
	// front
	glPushMatrix();
	glTranslated(0., 0., p);
	malha_unit(m, n);
	glPopMatrix();
	// back
	glPushMatrix();
	glTranslated(0., 0., -p);
	glRotated(180, 0, 1, 0);
	malha_unit(m, n);
	glPopMatrix();

	// top
	glPushMatrix();
	glTranslated(0., -p, 0.);
	glRotated(90, 1, 0, 0);
	malha_unit(m, n);
	glPopMatrix();

	// bottom
	glPushMatrix();
	glTranslated(0., p, 0.);
	glRotated(-90, 1, 0, 0);
	malha_unit(m, n);
	glPopMatrix();

	// left
	glPushMatrix();
	glTranslated(-p, 0., 0.);
	glRotated(-90, 0, 1, 0);
	malha_unit(m, n);
	glPopMatrix();

	// right
	glPushMatrix();
	glTranslated(p, 0., 0.);
	glRotated(90, 0, 1, 0);
	malha_unit(m, n);
	glPopMatrix();
}
	
//Função para desenhar um prédio com o auxilio da função cube_malha_unit();
inline void drawBuildingMalha(float posX, float posY, float posZ, float width, float height, float depth, float colorR, float colorG, float colorB, float m, float n) {

	glPushMatrix();
	glTranslatef(posX, posY, posZ);

	// Desenhar o prédio
	glColor3f(colorR, colorG, colorB);
	glPushMatrix();
	glScalef(width, height, depth);
	cube_malha_unit(m,n);
	glPopMatrix();
	glPopMatrix();
}
// Função para desenhar um elevador com o auxilio da função cube_unit()
inline void drawElevator(float elevatorPosX, float elevatorPosY,float  elevatorPosZ,float  elevatorWidth,float  elevatorHeight, float elevatorDepth) {
	glPushMatrix();
	glTranslatef(elevatorPosX, elevatorPosY, elevatorPosZ);

	glColor3f(0.098, 0.89, 0.851);  
	glScalef(elevatorWidth, elevatorHeight, elevatorDepth);
	cube_unit(); 
	glPopMatrix();
}
